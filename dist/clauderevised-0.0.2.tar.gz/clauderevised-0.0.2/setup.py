from setuptools import setup, find_packages


setup(
    name='clauderevised',
    version='0.0.2',
    url='https://github.com/boyueluzhipeng/claude_ai',
    packages=['clauderevised'],
    install_requires=[
        'requests',
    ],
)
